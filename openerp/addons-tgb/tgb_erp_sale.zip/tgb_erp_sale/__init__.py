# -*- coding: utf-8 -*-
import wizard
import account_invoice
import sale
import product
import partner
import stock